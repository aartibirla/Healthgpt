"""
healthgpt/model.py -- Full HealthGPT-Personal Model
Ties together PPE, P-LoRA, Hybrid Retrieval, and Safety Filter.

Architecture (Section 3, Figure 3):
  1. PersonalPatientEmbedding (ppe.py)       -- builds PPE vector p
  2. PatientConditionedAttention (plora.py)  -- LLM with g(p) bias + LoRA
  3. HybridRetriever (retrieval.py)          -- personalised evidence retrieval
  4. MedicalAlignmentAndRiskFilter (safety.py) -- validates output

NOTE ON BASE LLM:
  The paper specifies LLaMA-3-8B (Meta AI, 2024) as the base model.
  LLaMA-3 requires accepting Meta's Community Licence Agreement:
  https://llama.meta.com/llama-downloads/
  This code uses a placeholder LLM forward pass; to run with the real
  LLaMA-3-8B you need to download the weights and load them separately
  (e.g. via HuggingFace transformers after accepting the licence).
"""

from __future__ import annotations
from typing import Dict, List, Optional, Set

import torch
import torch.nn as nn

from .ppe import PersonalPatientEmbedding
from .plora import PatientConditionedAttention
from .retrieval import HybridRetriever, DocumentStore, UMLSKnowledgeGraph
from .safety import MedicalAlignmentAndRiskFilter


class HealthGPTPersonal(nn.Module):
    """
    Full HealthGPT-Personal framework.

    For a working inference run you need:
    1. MIMIC-IV v2.2 download (credentialed access required -- physionet.org)
    2. LLaMA-3-8B weights (Meta licence -- llama.meta.com/llama-downloads/)
    3. (Optional) UMLS licence for KG traversal -- uts.nlm.nih.gov
    4. (Optional) n2c2 notes for clinical text evaluation -- portal.dbmi.hms.harvard.edu

    Without these, you can still instantiate the model and test the
    architecture, but forward() will use a dummy LLM output.
    """

    def __init__(
        self,
        # PPE config
        code_vocab_size: int = 10000,
        code_embed_dim: int = 128,
        lab_input_dim: int = 64,
        note_dim: int = 768,
        imaging_dim: int = 512,
        demo_input_dim: int = 8,
        fusion_dim: int = 256,
        # LLM config
        llm_hidden_dim: int = 4096,   # LLaMA-3-8B hidden dim
        n_heads: int = 32,            # LLaMA-3-8B attention heads
        lora_rank: int = 32,
        lora_alpha: int = 64,
        # Retrieval config
        doc_store: Optional[DocumentStore] = None,
        kg: Optional[UMLSKnowledgeGraph] = None,
    ):
        super().__init__()

        # Component 1: Personal Patient Embedding
        self.ppe_module = PersonalPatientEmbedding(
            code_vocab_size=code_vocab_size,
            code_embed_dim=code_embed_dim,
            lab_input_dim=lab_input_dim,
            note_dim=note_dim,
            imaging_dim=imaging_dim,
            demo_input_dim=demo_input_dim,
            fusion_dim=fusion_dim,
        )

        # Component 2: Patient-Conditioned Attention (one layer shown;
        # in practice inserted at every attention layer of LLaMA-3-8B)
        self.patient_attn = PatientConditionedAttention(
            hidden_dim=llm_hidden_dim,
            n_heads=n_heads,
            ppe_dim=fusion_dim,
            rank=lora_rank,
            alpha=lora_alpha,
        )

        # Component 3: Hybrid retriever
        self.retriever = HybridRetriever(
            doc_store=doc_store or DocumentStore(),
            kg=kg,
            top_k_docs=5,
            kg_top_n=10,
            embed_dim=fusion_dim,
        )

        # Component 4: Safety filter
        self.safety_filter = MedicalAlignmentAndRiskFilter(
            hidden_dim=llm_hidden_dim,
        )

        # Query encoder (maps text query to fusion_dim vector for retrieval)
        self.query_encoder = nn.Sequential(
            nn.Linear(fusion_dim, fusion_dim),
            nn.ReLU(),
        )

    def encode_patient(
        self,
        code_ids: torch.Tensor,
        lab_seq: torch.Tensor,
        note_emb: torch.Tensor,
        img_emb: torch.Tensor,
        demographics: torch.Tensor,
    ) -> torch.Tensor:
        """
        Step 1: Build the PPE vector p (Algorithm 1).
        """
        return self.ppe_module(code_ids, lab_seq, note_emb, img_emb, demographics)

    def forward(
        self,
        # Patient inputs
        code_ids: torch.Tensor,        # (batch, num_codes)
        lab_seq: torch.Tensor,         # (batch, time_steps, lab_features)
        note_emb: torch.Tensor,        # (batch, 768)
        img_emb: torch.Tensor,         # (batch, 512)
        demographics: torch.Tensor,    # (batch, 8)
        # Query
        query_hidden: torch.Tensor,    # (batch, seq_len, llm_hidden_dim)
        query_vec: torch.Tensor,       # (batch, fusion_dim) for retrieval
        # Safety inputs
        allergies: List[Set[str]],
        contraindications: List[Set[str]],
        # Optional
        attention_mask: torch.Tensor = None,
        seed_cuis: Optional[List[List[str]]] = None,
    ) -> Dict:
        """
        Full forward pass through all four components.
        Returns dict with patient embedding, attention output, retrieved
        evidence, and safety-validated output.
        """
        batch_size = code_ids.shape[0]

        # Step 1: Build PPE
        ppe = self.encode_patient(code_ids, lab_seq, note_emb, img_emb, demographics)
        # ppe: (batch, fusion_dim)

        # Step 2: Patient-conditioned attention over LLM hidden states
        attn_output = self.patient_attn(query_hidden, ppe, attention_mask)
        # attn_output: (batch, seq_len, llm_hidden_dim)

        # Step 3: Personalised retrieval (Eq. 12)
        # Process per example in batch
        evidence_texts = []
        for i in range(batch_size):
            evidence = self.retriever.retrieve(
                query_vec=query_vec[i],
                ppe=ppe[i],
                seed_cuis=seed_cuis[i] if seed_cuis else None,
            )
            evidence_texts.append(evidence)

        # Step 4: Safety filter (applied per example)
        # In practice, h_out comes from the LLM's final hidden state
        # after generation; here we use the last token of attn_output
        h_out = attn_output[:, -1, :]  # (batch, llm_hidden_dim)

        # NOTE: In production, 'generated_text' comes from the LLM decoder.
        # This forward() returns the components needed to generate + validate.
        return {
            "ppe": ppe,                         # (batch, fusion_dim)
            "attn_output": attn_output,         # (batch, seq_len, hidden_dim)
            "evidence_texts": evidence_texts,   # list of str, one per example
            "h_out": h_out,                     # (batch, hidden_dim) for safety filter
        }

    def generate_and_validate(
        self,
        forward_output: Dict,
        generated_texts: List[str],     # from LLM decoder
        allergies: List[Set[str]],
        contraindications: List[Set[str]],
    ) -> List[Dict]:
        """
        Applies the safety filter to LLM-generated texts (Algorithm 3).
        Call this after decoding generated_texts from the LLM.
        """
        results = []
        h_out = forward_output["h_out"]  # (batch, hidden_dim)
        for i, text in enumerate(generated_texts):
            safe_result = self.safety_filter.apply(
                generated_text=text,
                h_out=h_out[i],
                allergies=allergies[i],
                contraindications=contraindications[i],
            )
            safe_result["evidence"] = forward_output["evidence_texts"][i]
            results.append(safe_result)
        return results

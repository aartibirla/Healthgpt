"""
healthgpt/preprocessing.py -- Data Preprocessing and Multimodal Alignment
Implements Section 4.2 / Algorithm 4 of the paper.

Algorithm 4:
  Input:  Raw clinical dataset D (from MIMIC-IV, n2c2, MONAI)
  Output: Temporally aligned multimodal sequence X = {x1, x2, ..., xT}
          where each x_t consolidates codes, labs, notes, imaging (Eq. 18)

DATA AVAILABILITY NOTE:
  This script processes data from:
  - MIMIC-IV v2.2: https://physionet.org/content/mimiciv/2.2/ (DUA required)
  - n2c2 2014-2018: https://portal.dbmi.hms.harvard.edu/ (DUA required)
  - MONAI imaging features: derived from MIMIC-IV imaging studies
  The raw data files cannot be redistributed. Obtain your own credentialed
  access via the links above before running this script.
"""

import os
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch


# ---------------------------------------------------------------------------
# Step 1: Clinical Code Embedding (Eq. 17)
# ---------------------------------------------------------------------------

def encode_clinical_codes(
    codes: List[str],
    vocab: Dict[str, int],
    unknown_id: int = 0,
) -> List[int]:
    """
    Eq. 17: e_c = W_e · one_hot(c)
    Maps ICD/CPT codes and medication IDs to integer indices for the
    ClinicalCodeEmbedding layer in ppe.py.
    """
    return [vocab.get(c, unknown_id) for c in codes]


# ---------------------------------------------------------------------------
# Step 2: Lab Time-Series Resampling (Section 4.2)
# ---------------------------------------------------------------------------

def resample_labs_to_24h_grid(
    lab_df: pd.DataFrame,
    lab_columns: List[str],
    time_col: str = "charttime",
    n_periods: int = 48,  # 48 x 30-min bins = 24 hours
) -> np.ndarray:
    """
    Resample irregular lab measurements onto a fixed 24-hour temporal grid.
    Missing values are forward-filled (clinically informed heuristic: most
    recent value is the best available estimate for a missing measurement).
    Returns: np.array of shape (n_periods, len(lab_columns))
    """
    lab_df = lab_df.copy()
    lab_df[time_col] = pd.to_datetime(lab_df[time_col])
    lab_df = lab_df.sort_values(time_col)

    # Create fixed grid
    if len(lab_df) == 0:
        return np.zeros((n_periods, len(lab_columns)))

    start = lab_df[time_col].iloc[0]
    grid_times = pd.date_range(start=start, periods=n_periods, freq="30min")

    # Reindex and forward-fill
    lab_df = lab_df.set_index(time_col)[lab_columns]
    resampled = lab_df.resample("30min").mean()
    resampled = resampled.reindex(grid_times, method="nearest", tolerance="30min")
    resampled = resampled.ffill().bfill().fillna(0.0)

    return resampled.values[:n_periods]  # (n_periods, n_lab_features)


# ---------------------------------------------------------------------------
# Step 3: Clinical Note Encoding (Section 4.2)
# ---------------------------------------------------------------------------

def encode_clinical_note(
    note_text: str,
    model_name: str = "emilyalsentzer/Bio_ClinicalBERT",
    max_length: int = 512,
) -> np.ndarray:
    """
    Encode de-identified clinical note via BioClinicalBERT.
    Returns CLS embedding of shape (768,).
    BioClinicalBERT: https://huggingface.co/emilyalsentzer/Bio_ClinicalBERT (public)

    n2c2 notes must be de-identified before encoding.
    MIMIC-IV notes are already de-identified at source.
    """
    try:
        from transformers import AutoTokenizer, AutoModel
        import torch
    except ImportError:
        raise ImportError("pip install transformers torch")

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name)
    model.eval()

    tokens = tokenizer(
        note_text, return_tensors="pt", truncation=True,
        max_length=max_length, padding="max_length"
    )
    with torch.no_grad():
        output = model(**tokens)
    cls_embedding = output.last_hidden_state[:, 0, :].squeeze().numpy()
    return cls_embedding  # (768,)


# ---------------------------------------------------------------------------
# Step 4: Imaging Feature Extraction (Section 4.2)
# ---------------------------------------------------------------------------

def extract_imaging_features(
    dicom_path: str,
    model_name: str = "google/vit-base-patch16-224",
) -> np.ndarray:
    """
    DICOM normalisation + ViT feature extraction (MONAI framework).
    Returns imaging embedding of shape (512,) for the PPE v modality.

    In the paper, MONAI is used for imaging studies linked to MIMIC-IV.
    MONAI: https://monai.io/ (open source, Apache 2.0 licence)

    If pydicom or monai are not installed, returns a zero vector with a warning.
    """
    try:
        import pydicom
        from transformers import ViTModel, ViTFeatureExtractor
        from PIL import Image
        import numpy as np
        import torch

        ds = pydicom.dcmread(dicom_path)
        pixel_array = ds.pixel_array.astype(np.float32)
        # Normalise to [0, 255]
        pixel_array = (pixel_array - pixel_array.min()) / (pixel_array.max() - pixel_array.min() + 1e-8) * 255
        image = Image.fromarray(pixel_array.astype(np.uint8)).convert("RGB")

        extractor = ViTFeatureExtractor.from_pretrained(model_name)
        model = ViTModel.from_pretrained(model_name)
        model.eval()

        inputs = extractor(images=image, return_tensors="pt")
        with torch.no_grad():
            outputs = model(**inputs)
        # CLS token as the imaging embedding, projected to 512 if needed
        embedding = outputs.last_hidden_state[:, 0, :].squeeze().numpy()
        return embedding[:512]

    except ImportError:
        print("WARNING: pydicom or transformers not installed. Returning zero imaging embedding.")
        return np.zeros(512)


# ---------------------------------------------------------------------------
# Step 5: Build Full Multimodal Sequence (Eq. 18)
# ---------------------------------------------------------------------------

def build_patient_sequence(
    code_ids: List[int],
    lab_array: np.ndarray,       # (n_periods, n_lab_features)
    note_embedding: np.ndarray,  # (768,)
    imaging_embedding: np.ndarray,  # (512,)
    demographics: np.ndarray,    # (8,) -- age, sex, BMI, 5 habit flags
) -> Dict[str, torch.Tensor]:
    """
    Eq. 18: X = {x1, x2, ..., xT}
    Assembles all modalities into the dict consumed by PersonalPatientEmbedding.

    Returns a dict of torch.Tensors (batch dim = 1, ready for PPE forward pass).
    """
    return {
        "code_ids": torch.tensor([code_ids], dtype=torch.long),
        "lab_seq": torch.tensor(lab_array, dtype=torch.float32).unsqueeze(0),
        "note_emb": torch.tensor(note_embedding, dtype=torch.float32).unsqueeze(0),
        "img_emb": torch.tensor(imaging_embedding, dtype=torch.float32).unsqueeze(0),
        "demographics": torch.tensor(demographics, dtype=torch.float32).unsqueeze(0),
    }


# ---------------------------------------------------------------------------
# MIMIC-IV Data Loader skeleton (DUA required)
# ---------------------------------------------------------------------------

def load_mimic_iv_patient(
    mimic_root: str,
    subject_id: int,
) -> Dict:
    """
    Load one patient's data from a local MIMIC-IV v2.2 download.

    REQUIRES: Credentialed PhysioNet access + local download.
    Download: https://physionet.org/content/mimiciv/2.2/

    Returns a dict with raw DataFrames for the patient:
      admissions, diagnoses, prescriptions, labevents, notes
    """
    if not os.path.exists(mimic_root):
        raise FileNotFoundError(
            f"MIMIC-IV root not found at {mimic_root}. "
            "Download from https://physionet.org/content/mimiciv/2.2/ "
            "after obtaining credentialed PhysioNet access."
        )

    hosp_dir = os.path.join(mimic_root, "hosp")
    note_dir = os.path.join(mimic_root, "note")  # if available

    admissions = pd.read_csv(os.path.join(hosp_dir, "admissions.csv.gz"))
    admissions = admissions[admissions["subject_id"] == subject_id]

    diagnoses = pd.read_csv(os.path.join(hosp_dir, "diagnoses_icd.csv.gz"))
    diagnoses = diagnoses[diagnoses["subject_id"] == subject_id]

    prescriptions = pd.read_csv(os.path.join(hosp_dir, "prescriptions.csv.gz"))
    prescriptions = prescriptions[prescriptions["subject_id"] == subject_id]

    labevents = pd.read_csv(os.path.join(hosp_dir, "labevents.csv.gz"))
    labevents = labevents[labevents["subject_id"] == subject_id]

    return {
        "subject_id": subject_id,
        "admissions": admissions,
        "diagnoses": diagnoses,
        "prescriptions": prescriptions,
        "labevents": labevents,
    }

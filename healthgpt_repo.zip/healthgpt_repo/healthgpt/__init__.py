"""
HealthGPT-Personal: Multimodal Patient-Specific Clinical Decision Support
Using Personalised Large Language Models.

Data availability:
  - MIMIC-IV v2.2: https://physionet.org/content/mimiciv/2.2/ (DUA required)
  - n2c2 (2014-2018): https://portal.dbmi.hms.harvard.edu/ (DUA required)
  - MedQA, MedMCQA, PubMedQA: public (no DUA)
"""

from .ppe import PersonalPatientEmbedding
from .plora import LoRALinear, PatientConditionedAttention
from .retrieval import HybridRetriever, DocumentStore, UMLSKnowledgeGraph
from .safety import MedicalAlignmentAndRiskFilter, HallucinationRiskClassifier, MedicationSafetyChecker
from .model import HealthGPTPersonal
from .preprocessing import (
    encode_clinical_codes,
    resample_labs_to_24h_grid,
    encode_clinical_note,
    build_patient_sequence,
    load_mimic_iv_patient,
)

__version__ = "1.0.0"
__all__ = [
    "HealthGPTPersonal",
    "PersonalPatientEmbedding",
    "PatientConditionedAttention",
    "LoRALinear",
    "HybridRetriever",
    "DocumentStore",
    "UMLSKnowledgeGraph",
    "MedicalAlignmentAndRiskFilter",
    "HallucinationRiskClassifier",
    "MedicationSafetyChecker",
    "encode_clinical_codes",
    "resample_labs_to_24h_grid",
    "encode_clinical_note",
    "build_patient_sequence",
    "load_mimic_iv_patient",
]

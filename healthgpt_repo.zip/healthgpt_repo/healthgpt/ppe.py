"""
healthgpt/ppe.py -- Personal Patient Embedding (PPE)
Implements Section 3.2 of the paper.

Algorithm 1: Personalised Patient Representation Learning

The PPE integrates five modalities:
  - e_c : EHR clinical code embedding  (Eq. 17)
  - h_l : Lab time-series temporal embedding
  - n   : Clinical note semantic vector (BioClinicalBERT)
  - v   : Imaging feature vector (MONAI ViT encoder)
  - d   : Demographic vector (age, sex, BMI, habits)

These are fused via cross-modal attention into z_patient = p (the PPE vector).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ClinicalCodeEmbedding(nn.Module):
    """
    Eq. 17: e_c = W_e · one_hot(c)
    Learns dense embeddings for ICD/CPT codes and medication identifiers.
    """
    def __init__(self, vocab_size: int, embed_dim: int):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)

    def forward(self, code_ids: torch.Tensor) -> torch.Tensor:
        # code_ids: (batch, num_codes)
        # returns:  (batch, num_codes, embed_dim)
        return self.embedding(code_ids)


class LabTemporalEncoder(nn.Module):
    """
    Encodes irregular lab sequences resampled to a 24-hour grid (Section 4.2).
    Uses a Transformer encoder to produce h_l.
    """
    def __init__(self, input_dim: int, hidden_dim: int, n_heads: int = 4, n_layers: int = 2):
        super().__init__()
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim, nhead=n_heads,
            dim_feedforward=hidden_dim * 4, batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)
        self.pool = nn.AdaptiveAvgPool1d(1)

    def forward(self, lab_seq: torch.Tensor, mask: torch.Tensor = None) -> torch.Tensor:
        # lab_seq: (batch, time_steps, input_dim)
        x = self.input_proj(lab_seq)                      # (batch, T, hidden_dim)
        x = self.transformer(x, src_key_padding_mask=mask)
        x = self.pool(x.transpose(1, 2)).squeeze(-1)      # (batch, hidden_dim)
        return x


class DemographicEncoder(nn.Module):
    """
    Encodes age, sex (binary), BMI, and habit flags into a dense vector d.
    """
    def __init__(self, input_dim: int, hidden_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )

    def forward(self, demographics: torch.Tensor) -> torch.Tensor:
        # demographics: (batch, input_dim)
        return self.net(demographics)


class CrossModalAttentionFusion(nn.Module):
    """
    Algorithm 1, Step 4: z_patient = fusion(e_c, h_l, n, v_img, d)
    Uses cross-modal attention to fuse all five modality vectors.
    """
    def __init__(self, modality_dim: int, n_heads: int = 4):
        super().__init__()
        self.attn = nn.MultiheadAttention(
            embed_dim=modality_dim, num_heads=n_heads, batch_first=True
        )
        self.norm = nn.LayerNorm(modality_dim)
        self.out_proj = nn.Linear(modality_dim, modality_dim)

    def forward(self, modalities: list) -> torch.Tensor:
        """
        modalities: list of tensors, each (batch, modality_dim)
        Returns: z_patient (batch, modality_dim)
        """
        # Stack into sequence: (batch, num_modalities, modality_dim)
        x = torch.stack(modalities, dim=1)
        # Self-attention across modalities
        attn_out, _ = self.attn(x, x, x)
        x = self.norm(x + attn_out)
        # Mean pool across modality dimension -> PPE vector p
        z = x.mean(dim=1)
        return self.out_proj(z)


class PersonalPatientEmbedding(nn.Module):
    """
    Full PPE module (Section 3.2 / Algorithm 1).

    Accepts five modality inputs and returns p = z_patient,
    the unified Personal Patient Embedding.

    NOTE ON DATA AVAILABILITY:
    - EHR codes and labs: from MIMIC-IV (https://physionet.org/content/mimiciv/2.2/)
      Requires credentialed PhysioNet access + DUA.
    - Clinical notes: from n2c2 (https://portal.dbmi.hms.harvard.edu/)
      Requires Harvard DBMI DUA. Currently temporarily unavailable.
    - Note embeddings (n): produced by BioClinicalBERT
      (https://huggingface.co/emilyalsentzer/Bio_ClinicalBERT) -- public.
    - Imaging (v): produced by MONAI ViT encoder
      (https://monai.io/) -- public framework, imaging data from MIMIC-IV.
    - Demographics: from MIMIC-IV patients table -- requires DUA as above.
    """
    def __init__(
        self,
        code_vocab_size: int = 10000,
        code_embed_dim: int = 128,
        lab_input_dim: int = 64,
        note_dim: int = 768,       # BioClinicalBERT output dim
        imaging_dim: int = 512,    # MONAI ViT output dim
        demo_input_dim: int = 8,   # age, sex, BMI + 5 habit flags
        fusion_dim: int = 256,
    ):
        super().__init__()
        self.code_embed = ClinicalCodeEmbedding(code_vocab_size, code_embed_dim)
        self.code_pool = nn.AdaptiveAvgPool1d(1)
        self.code_proj = nn.Linear(code_embed_dim, fusion_dim)

        self.lab_encoder = LabTemporalEncoder(lab_input_dim, fusion_dim)

        self.note_proj = nn.Linear(note_dim, fusion_dim)
        self.img_proj = nn.Linear(imaging_dim, fusion_dim)
        self.demo_encoder = DemographicEncoder(demo_input_dim, fusion_dim)

        self.fusion = CrossModalAttentionFusion(fusion_dim)

    def forward(
        self,
        code_ids: torch.Tensor,       # (batch, num_codes)
        lab_seq: torch.Tensor,        # (batch, time_steps, lab_features)
        note_emb: torch.Tensor,       # (batch, 768) -- BioClinicalBERT CLS
        img_emb: torch.Tensor,        # (batch, 512) -- MONAI ViT
        demographics: torch.Tensor,   # (batch, 8)
        lab_mask: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Returns p = z_patient: (batch, fusion_dim)
        This is the PPE vector used in patient-conditioned attention (Eq. 11)
        and personalised retrieval (Eq. 12).
        """
        # Encode each modality
        e_c = self.code_proj(
            self.code_pool(
                self.code_embed(code_ids).transpose(1, 2)
            ).squeeze(-1)
        )                               # (batch, fusion_dim)
        h_l = self.lab_encoder(lab_seq, lab_mask)   # (batch, fusion_dim)
        n = self.note_proj(note_emb)                # (batch, fusion_dim)
        v = self.img_proj(img_emb)                  # (batch, fusion_dim)
        d = self.demo_encoder(demographics)         # (batch, fusion_dim)

        # Cross-modal attention fusion -> PPE vector p
        p = self.fusion([e_c, h_l, n, v, d])       # (batch, fusion_dim)
        return p

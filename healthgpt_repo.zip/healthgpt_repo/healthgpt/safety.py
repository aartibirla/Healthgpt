"""
healthgpt/safety.py -- Medical Alignment and Risk Filter
Implements Section 3.4 of the paper, Equations 14, 15, and 16.

Applied in fixed sequence for EVERY generated output (Section 3.4):
  1. Hallucination-risk classifier (Eq. 14) -- neural
  2. Medication contraindication check (Eq. 15) -- rule-based
  3. Confidence score computation (Eq. 16)

Eq. 14: s_risk = σ(W_r · h_out)
  -- linear probe on frozen LLaMA-3-8B output embedding.
  -- IMPORTANT: training labels are SILVER LABELS from BERTScore >= 0.85
     (not human-annotated ground truth). This limitation is stated in
     Sections 3.3 and 8.2 of the paper and affects interpretation of
     reported hallucination-reduction figures.

Eq. 15: valid = ∧_{m∈M} (m ∉ A_allergy) ∧ (m ∉ C_contra)

Eq. 16: conf = λ₁·s_evidence + λ₂·s_similarity + λ₃·s_guideline
  -- λ₁=0.5, λ₂=0.3, λ₃=0.2 (as in L_total loss weights, Section 3)
"""

from __future__ import annotations

import re
from typing import List, Set, Dict, Tuple

import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# Eq. 14 -- Neural Hallucination-Risk Classifier
# ---------------------------------------------------------------------------

class HallucinationRiskClassifier(nn.Module):
    """
    Linear probe trained on the frozen LLaMA-3-8B output embedding h_out.
    Eq. 14: s_risk = σ(W_r · h_out)

    Training labels are automatically constructed silver labels:
    a generated claim is labelled as hallucinated (1) if its BERTScore
    against the retrieved evidence set is below 0.85, and not hallucinated
    (0) otherwise. This is NOT based on human clinician annotation.

    See Section 8.2 (Limitations) for the circularity implications and the
    planned extension to independent clinician-annotated labels.

    Risk threshold τ = 0.4 (selected on validation set by maximising F1,
    as stated in Table 2 of the paper).
    """
    TAU = 0.4  # Section 3.4 / Table 2

    def __init__(self, hidden_dim: int = 4096):
        super().__init__()
        # W_r: a single linear layer mapping LLaMA hidden state -> risk scalar
        self.W_r = nn.Linear(hidden_dim, 1, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, h_out: torch.Tensor) -> torch.Tensor:
        """
        h_out: (batch, hidden_dim) -- last-token hidden state from LLaMA-3-8B
        Returns: s_risk (batch,) in (0, 1)
        """
        return self.sigmoid(self.W_r(h_out)).squeeze(-1)

    def is_high_risk(self, s_risk: torch.Tensor) -> torch.Tensor:
        """Returns boolean mask: True where s_risk > τ (triggers regeneration)."""
        return s_risk > self.TAU


# ---------------------------------------------------------------------------
# Eq. 15 -- Rule-Based Medication Contraindication Check
# ---------------------------------------------------------------------------

class MedicationSafetyChecker:
    """
    Rule-based check (Eq. 15).
    valid = ∧_{m∈M} (m ∉ A_allergy) ∧ (m ∉ C_contra)

    Extracts medication mentions from generated text using simple regex
    (production use should replace this with a clinical NER model like
    MedSpaCy or BioBERT-NER for more robust extraction).

    Allergy set A and contraindication set C come from the patient's
    MIMIC-IV records (allergies and problem-list/drug-interaction tables).
    """

    # Simple regex for medication extraction -- replace with NER in production
    MED_PATTERN = re.compile(
        r'\b(?:prescribed|recommend(?:ed)?|administer(?:ing)?|give|start)\s+(\w+(?:\s+\w+)?)',
        re.IGNORECASE,
    )

    def extract_medications(self, text: str) -> List[str]:
        """Extract medication names mentioned in generated text."""
        return [m.group(1).lower().strip() for m in self.MED_PATTERN.finditer(text)]

    def validate(
        self,
        generated_text: str,
        allergies: Set[str],
        contraindications: Set[str],
    ) -> Tuple[bool, List[str]]:
        """
        Eq. 15: checks that no recommended medication is in A or C.
        Returns (is_valid, list_of_violations).
        """
        meds = self.extract_medications(generated_text)
        violations = [
            m for m in meds
            if m in allergies or m in contraindications
        ]
        return len(violations) == 0, violations

    def remove_violations(self, text: str, violations: List[str]) -> str:
        """Remove or flag violating medication mentions from the output."""
        for med in violations:
            text = re.sub(
                rf'\b{re.escape(med)}\b',
                f'[CONTRAINDICATED: {med}]',
                text,
                flags=re.IGNORECASE,
            )
        return text


# ---------------------------------------------------------------------------
# Eq. 16 -- Confidence Score
# ---------------------------------------------------------------------------

def compute_confidence(
    s_evidence: float,
    s_similarity: float,
    s_guideline: float,
    lambda1: float = 0.5,
    lambda2: float = 0.3,
    lambda3: float = 0.2,
) -> float:
    """
    Eq. 16: conf = λ₁·s_evidence + λ₂·s_similarity + λ₃·s_guideline
    Returns a scalar in [0, 1] representing overall output confidence.
    """
    return lambda1 * s_evidence + lambda2 * s_similarity + lambda3 * s_guideline


# ---------------------------------------------------------------------------
# Full Safety Pipeline (Section 3.4 -- applied in fixed sequence)
# ---------------------------------------------------------------------------

class MedicalAlignmentAndRiskFilter:
    """
    Orchestrates the three-step safety pipeline (Section 3.4):
      Step 1: Hallucination-risk classifier (Eq. 14)
      Step 2: Medication contraindication check (Eq. 15)
      Step 3: Confidence score (Eq. 16)

    Applied to every output, unconditionally, in that fixed order.
    """

    def __init__(self, hidden_dim: int = 4096):
        self.hallucination_clf = HallucinationRiskClassifier(hidden_dim)
        self.med_checker = MedicationSafetyChecker()

    def apply(
        self,
        generated_text: str,
        h_out: torch.Tensor,          # LLaMA last-token embedding
        allergies: Set[str],
        contraindications: Set[str],
        s_evidence: float = 0.8,      # from retrieval similarity score
        s_similarity: float = 0.7,    # from patient-similarity score
        s_guideline: float = 0.75,    # from KG alignment score
    ) -> Dict:
        """
        Returns a dict with:
          - safe_output: the validated, cleaned text
          - s_risk: hallucination risk score
          - high_risk: bool, whether regeneration was triggered
          - violations: list of medication violations found
          - confidence: final conf score (Eq. 16)
        """
        # Step 1: Hallucination risk (Eq. 14)
        with torch.no_grad():
            s_risk = self.hallucination_clf(h_out.unsqueeze(0)).item()
        high_risk = s_risk > HallucinationRiskClassifier.TAU

        # If high risk, in production the LLM would be called again;
        # here we flag it in the output for downstream handling
        output = generated_text
        if high_risk:
            output = f"[HIGH_HALLUCINATION_RISK: s_risk={s_risk:.3f}] " + output

        # Step 2: Medication contraindication check (Eq. 15)
        is_valid, violations = self.med_checker.validate(output, allergies, contraindications)
        if not is_valid:
            output = self.med_checker.remove_violations(output, violations)

        # Step 3: Confidence score (Eq. 16)
        confidence = compute_confidence(s_evidence, s_similarity, s_guideline)

        return {
            "safe_output": output,
            "s_risk": s_risk,
            "high_risk": high_risk,
            "violations": violations,
            "confidence": round(confidence, 4),
        }

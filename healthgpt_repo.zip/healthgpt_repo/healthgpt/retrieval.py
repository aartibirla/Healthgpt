"""
healthgpt/retrieval.py -- Hybrid RAG + UMLS Knowledge-Graph Retrieval
Implements Section 3.3 of the paper, Equations 12 and 13.

Eq. 12: R = TopK( sim(q + p, K) )
  -- personalised retrieval: both query q and patient state p influence
     which documents are retrieved from the knowledge corpus K.

Eq. 13: G = (V, E), (u,v) ∈ E => medical relation exists
  -- the biomedical knowledge graph, instantiated from UMLS Metathesaurus,
     restricted to disease/symptom/medication/contraindication relations,
     traversed via bounded BFS (max 2 hops, top-10 confidence-ranked relations).

NOTE ON KNOWLEDGE GRAPH DATA AVAILABILITY:
  UMLS Metathesaurus requires a free UMLS Terminology Services licence.
  Apply at: https://uts.nlm.nih.gov/uts/signup-login
  Once licensed, download MRCONSO.RRF and MRREL.RRF for graph construction.
  Without a UMLS licence, the KG traversal step is skipped and only
  RAG-based retrieval is used (see use_kg flag in HybridRetriever).
"""

import math
import heapq
from collections import defaultdict, deque
from typing import List, Tuple, Optional

import torch
import torch.nn.functional as F


class DocumentStore:
    """
    Simple in-memory document store for the knowledge corpus K.
    In production, replace with a FAISS or Elasticsearch index for
    the clinical guidelines + PubMed abstracts corpus.
    """
    def __init__(self):
        self.documents = []       # list of str
        self.embeddings = None    # torch.Tensor (N, embed_dim)

    def add_documents(self, docs: List[str], embeddings: torch.Tensor):
        self.documents.extend(docs)
        if self.embeddings is None:
            self.embeddings = embeddings
        else:
            self.embeddings = torch.cat([self.embeddings, embeddings], dim=0)

    def top_k(
        self,
        query_vec: torch.Tensor,   # (embed_dim,)
        k: int = 5,
    ) -> List[Tuple[float, str]]:
        """
        Eq. 12: sim(q + p, K) -- cosine similarity between personalised
        query vector and each document embedding. Returns top-k.
        """
        if self.embeddings is None or len(self.documents) == 0:
            return []
        sims = F.cosine_similarity(
            query_vec.unsqueeze(0), self.embeddings, dim=-1
        )
        k = min(k, len(self.documents))
        topk_scores, topk_idx = torch.topk(sims, k)
        return [
            (topk_scores[i].item(), self.documents[topk_idx[i]])
            for i in range(k)
        ]


class UMLSKnowledgeGraph:
    """
    UMLS Metathesaurus knowledge graph (Eq. 13).
    Restricted to disease, symptom, medication, contraindication relation types.
    Traversal: bounded BFS, max 2 hops, returns top-10 confidence-ranked relations.

    DATA AVAILABILITY:
    Requires UMLS licence: https://uts.nlm.nih.gov/uts/signup-login
    After licensing, load MRCONSO.RRF + MRREL.RRF via load_from_umls_files().
    Without a licence, this class returns empty results (KG step is skipped).
    """

    # Relation types to include (from MRREL.RRF REL/RELA columns)
    ALLOWED_REL_TYPES = {
        "has_contraindication", "contraindicated_with",
        "may_treat", "treats",
        "has_symptom", "symptom_of",
        "associated_with", "related_to",
    }

    def __init__(self):
        # adjacency: cui -> list of (related_cui, relation_type, confidence)
        self.adj = defaultdict(list)
        self.cui_to_name = {}  # CUI -> preferred English name
        self._loaded = False

    def load_from_umls_files(self, mrconso_path: str, mrrel_path: str):
        """
        Load UMLS CUI names from MRCONSO.RRF and relations from MRREL.RRF.
        Only call this if you have a valid UMLS licence and downloaded files.
        """
        # Load preferred English names from MRCONSO
        with open(mrconso_path, encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) < 15:
                    continue
                cui, lang, ts = parts[0], parts[1], parts[2]
                preferred_name = parts[14]
                if lang == "ENG" and ts == "P" and cui not in self.cui_to_name:
                    self.cui_to_name[cui] = preferred_name

        # Load filtered relations from MRREL
        with open(mrrel_path, encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) < 16:
                    continue
                cui1, rela, cui2 = parts[0], parts[7], parts[4]
                if rela in self.ALLOWED_REL_TYPES:
                    # Use 1.0 as default confidence (UMLS doesn't always have scores)
                    self.adj[cui1].append((cui2, rela, 1.0))

        self._loaded = True
        print(f"Loaded UMLS graph: {len(self.cui_to_name)} concepts, {sum(len(v) for v in self.adj.values())} relations")

    def bfs_traverse(
        self,
        seed_cuis: List[str],
        max_hops: int = 2,
        top_n: int = 10,
    ) -> List[str]:
        """
        Bounded BFS from seed CUIs, up to max_hops.
        Returns top_n relations sorted by confidence, serialised as
        natural-language statements appended to retrieved evidence.
        """
        if not self._loaded:
            return []  # KG step silently skipped if UMLS not loaded

        visited = set(seed_cuis)
        queue = deque([(cui, 0) for cui in seed_cuis])
        candidates = []  # (confidence, statement)

        while queue:
            cui, depth = queue.popleft()
            if depth >= max_hops:
                continue
            for related_cui, rel_type, conf in self.adj.get(cui, []):
                if related_cui not in visited:
                    visited.add(related_cui)
                    queue.append((related_cui, depth + 1))
                    name1 = self.cui_to_name.get(cui, cui)
                    name2 = self.cui_to_name.get(related_cui, related_cui)
                    statement = f"{name1} {rel_type.replace('_', ' ')} {name2}."
                    heapq.heappush(candidates, (-conf, statement))

        return [stmt for _, stmt in heapq.nsmallest(top_n, candidates)]


class HybridRetriever:
    """
    Combines document retrieval (Eq. 12) with UMLS KG traversal (Eq. 13).
    Called during inference to build the evidence context for the LLM.
    """
    def __init__(
        self,
        doc_store: DocumentStore,
        kg: Optional[UMLSKnowledgeGraph] = None,
        top_k_docs: int = 5,
        kg_top_n: int = 10,
        embed_dim: int = 256,
    ):
        self.doc_store = doc_store
        self.kg = kg
        self.top_k_docs = top_k_docs
        self.kg_top_n = kg_top_n

    def retrieve(
        self,
        query_vec: torch.Tensor,  # (embed_dim,) -- query q
        ppe: torch.Tensor,        # (embed_dim,) -- patient embedding p
        seed_cuis: List[str] = None,
    ) -> str:
        """
        Eq. 12: personalised_query = q + p, then retrieve top-K documents.
        Eq. 13: BFS from entities in retrieved passages + patient problem list.
        Returns a single string with all retrieved evidence concatenated.
        """
        # Personalised query vector: q + p (Eq. 12)
        personalised_q = query_vec + ppe

        # Document retrieval
        doc_results = self.doc_store.top_k(personalised_q, k=self.top_k_docs)
        doc_texts = [doc for _, doc in doc_results]

        # KG traversal (Eq. 13) -- skipped if no UMLS licence
        kg_statements = []
        if self.kg is not None and seed_cuis:
            kg_statements = self.kg.bfs_traverse(
                seed_cuis, max_hops=2, top_n=self.kg_top_n
            )

        # Serialise: retrieved docs + KG statements appended
        evidence_parts = doc_texts + kg_statements
        return "\n".join(evidence_parts) if evidence_parts else ""

"""
healthgpt/plora.py -- Personalised Low-Rank Adaptation (P-LoRA)
Implements Section 3.3 of the paper, Equations 10 and 11.

Eq. 10:  h' = h + B·A·h          (shared LoRA update)
Eq. 11:  α_ij = softmax( (Q_i + g(p))(K_j + g(p))^T / sqrt(d_k) )

As clarified in Section 3.3 of the paper:
  - Matrices A and B are SHARED across all patients (not per-patient).
  - Patient-specific conditioning enters via g(p): a nonlinear projection
    of the PPE added to Q and K before the attention softmax.
  - This should be understood as standard LoRA + patient-conditioned
    attention bias, not as patient-specific LoRA matrices.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class LoRALinear(nn.Module):
    """
    Shared LoRA adapter for one linear projection layer.
    Eq. 10: h' = h + B·A·h
    rank r=32, scaling alpha=64 (as specified in Section 3.3).
    """
    def __init__(self, in_features: int, out_features: int, rank: int = 32, alpha: int = 64):
        super().__init__()
        self.rank = rank
        self.alpha = alpha
        self.scaling = alpha / rank

        # Base weight (frozen during adaptation; load from pretrained LLaMA-3-8B)
        self.base_weight = nn.Linear(in_features, out_features, bias=False)
        self.base_weight.weight.requires_grad_(False)

        # Shared LoRA matrices A and B (trained, shared across all patients)
        self.lora_A = nn.Linear(in_features, rank, bias=False)
        self.lora_B = nn.Linear(rank, out_features, bias=False)

        # Initialise A with Gaussian, B with zeros (standard LoRA init)
        nn.init.kaiming_uniform_(self.lora_A.weight, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B.weight)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Base forward + scaled LoRA delta
        return self.base_weight(x) + self.scaling * self.lora_B(self.lora_A(x))


class PatientConditionedAttention(nn.Module):
    """
    Patient-conditioned multi-head attention (Eq. 11).
    g(p) is added to both Q and K projections before the attention softmax,
    so that attention weights vary with patient-specific context.

    This is applied at every attention layer in the LLaMA-3-8B backbone.
    """
    def __init__(
        self,
        hidden_dim: int,
        n_heads: int,
        ppe_dim: int,
        rank: int = 32,
        alpha: int = 64,
    ):
        super().__init__()
        self.n_heads = n_heads
        self.head_dim = hidden_dim // n_heads
        self.scale = math.sqrt(self.head_dim)

        # LoRA-adapted Q, K, V, O projections (shared across patients)
        self.q_proj = LoRALinear(hidden_dim, hidden_dim, rank, alpha)
        self.k_proj = LoRALinear(hidden_dim, hidden_dim, rank, alpha)
        self.v_proj = LoRALinear(hidden_dim, hidden_dim, rank, alpha)
        self.o_proj = LoRALinear(hidden_dim, hidden_dim, rank, alpha)

        # g(p): nonlinear projection of PPE -> patient-conditioned attention bias
        # Shape: PPE vector -> (n_heads, head_dim) for adding to Q and K
        self.gp_proj = nn.Sequential(
            nn.Linear(ppe_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
        )

    def forward(
        self,
        hidden_states: torch.Tensor,   # (batch, seq_len, hidden_dim)
        ppe: torch.Tensor,             # (batch, ppe_dim) -- the PPE vector p
        attention_mask: torch.Tensor = None,
    ) -> torch.Tensor:
        batch, seq_len, _ = hidden_states.shape

        # Compute Q, K, V via shared LoRA-adapted projections (Eq. 10)
        Q = self.q_proj(hidden_states)  # (batch, seq_len, hidden_dim)
        K = self.k_proj(hidden_states)
        V = self.v_proj(hidden_states)

        # Compute patient-conditioned bias g(p) and add to Q and K (Eq. 11)
        gp = self.gp_proj(ppe).unsqueeze(1)  # (batch, 1, hidden_dim)
        Q = Q + gp
        K = K + gp

        # Reshape for multi-head attention
        def split_heads(x):
            return x.view(batch, seq_len, self.n_heads, self.head_dim).transpose(1, 2)

        Q, K, V = split_heads(Q), split_heads(K), split_heads(V)

        # Scaled dot-product attention (Eq. 11 softmax)
        attn_weights = torch.matmul(Q, K.transpose(-2, -1)) / self.scale
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask
        attn_weights = F.softmax(attn_weights, dim=-1)

        attn_out = torch.matmul(attn_weights, V)
        attn_out = attn_out.transpose(1, 2).contiguous().view(batch, seq_len, -1)

        return self.o_proj(attn_out)

"""
tests/test_components.py -- Unit tests for all HealthGPT-Personal components.
These tests use only synthetic data and require NO dataset access.
Run: python -m pytest tests/test_components.py -v
"""

import pytest
import torch
import numpy as np


# ---------------------------------------------------------------------------
# PPE Tests
# ---------------------------------------------------------------------------

def test_ppe_forward():
    from healthgpt.ppe import PersonalPatientEmbedding
    batch = 2
    model = PersonalPatientEmbedding(
        code_vocab_size=100, code_embed_dim=32,
        lab_input_dim=10, note_dim=64,
        imaging_dim=32, demo_input_dim=8, fusion_dim=64,
    )
    code_ids = torch.randint(0, 100, (batch, 5))
    lab_seq = torch.randn(batch, 12, 10)
    note_emb = torch.randn(batch, 64)
    img_emb = torch.randn(batch, 32)
    demographics = torch.randn(batch, 8)

    ppe = model(code_ids, lab_seq, note_emb, img_emb, demographics)
    assert ppe.shape == (batch, 64), f"Expected (2, 64), got {ppe.shape}"


# ---------------------------------------------------------------------------
# P-LoRA Tests
# ---------------------------------------------------------------------------

def test_lora_linear_forward():
    from healthgpt.plora import LoRALinear
    layer = LoRALinear(in_features=64, out_features=64, rank=4, alpha=8)
    x = torch.randn(2, 10, 64)
    out = layer(x)
    assert out.shape == (2, 10, 64)


def test_patient_conditioned_attention():
    from healthgpt.plora import PatientConditionedAttention
    attn = PatientConditionedAttention(
        hidden_dim=64, n_heads=4, ppe_dim=64, rank=4, alpha=8
    )
    hidden = torch.randn(2, 10, 64)
    ppe = torch.randn(2, 64)
    out = attn(hidden, ppe)
    assert out.shape == (2, 10, 64)


def test_gp_bias_changes_output():
    """g(p) should change attention output when patient embedding changes."""
    from healthgpt.plora import PatientConditionedAttention
    attn = PatientConditionedAttention(
        hidden_dim=64, n_heads=4, ppe_dim=64, rank=4, alpha=8
    )
    attn.eval()
    hidden = torch.randn(1, 5, 64)
    ppe_1 = torch.zeros(1, 64)
    ppe_2 = torch.ones(1, 64)
    with torch.no_grad():
        out1 = attn(hidden, ppe_1)
        out2 = attn(hidden, ppe_2)
    assert not torch.allclose(out1, out2), "g(p) should change output for different patients"


# ---------------------------------------------------------------------------
# Retrieval Tests
# ---------------------------------------------------------------------------

def test_document_store_topk():
    from healthgpt.retrieval import DocumentStore
    import torch
    store = DocumentStore()
    docs = ["Heart disease treatment", "Diabetes management", "Hypertension drugs"]
    embs = torch.randn(3, 32)
    store.add_documents(docs, embs)

    query = torch.randn(32)
    results = store.top_k(query, k=2)
    assert len(results) == 2
    assert all(isinstance(r[1], str) for r in results)


def test_retriever_returns_string():
    from healthgpt.retrieval import HybridRetriever, DocumentStore
    store = DocumentStore()
    store.add_documents(["Clinical guideline A"], torch.randn(1, 32))
    retriever = HybridRetriever(store, top_k_docs=1)
    evidence = retriever.retrieve(torch.randn(32), torch.randn(32))
    assert isinstance(evidence, str)


# ---------------------------------------------------------------------------
# Safety Filter Tests
# ---------------------------------------------------------------------------

def test_hallucination_classifier():
    from healthgpt.safety import HallucinationRiskClassifier
    clf = HallucinationRiskClassifier(hidden_dim=64)
    h_out = torch.randn(3, 64)
    risk = clf(h_out)
    assert risk.shape == (3,)
    assert (risk >= 0).all() and (risk <= 1).all()


def test_medication_checker_catches_violation():
    from healthgpt.safety import MedicationSafetyChecker
    checker = MedicationSafetyChecker()
    text = "I recommend prescribing penicillin for this patient."
    is_valid, violations = checker.validate(
        text,
        allergies={"penicillin"},
        contraindications=set(),
    )
    assert not is_valid
    assert "penicillin" in violations


def test_medication_checker_passes_safe_output():
    from healthgpt.safety import MedicationSafetyChecker
    checker = MedicationSafetyChecker()
    text = "Recommend prescribing metformin for glucose control."
    is_valid, violations = checker.validate(
        text,
        allergies={"penicillin"},
        contraindications={"warfarin"},
    )
    assert is_valid
    assert len(violations) == 0


def test_confidence_score():
    from healthgpt.safety import compute_confidence
    conf = compute_confidence(s_evidence=0.8, s_similarity=0.7, s_guideline=0.9)
    expected = 0.5 * 0.8 + 0.3 * 0.7 + 0.2 * 0.9
    assert abs(conf - expected) < 1e-5


# ---------------------------------------------------------------------------
# Preprocessing Tests
# ---------------------------------------------------------------------------

def test_resample_labs():
    from healthgpt.preprocessing import resample_labs_to_24h_grid
    import pandas as pd
    lab_df = pd.DataFrame({
        "charttime": pd.date_range("2023-01-01", periods=10, freq="2h"),
        "glucose": np.random.randn(10),
        "sodium": np.random.randn(10),
    })
    result = resample_labs_to_24h_grid(lab_df, ["glucose", "sodium"], n_periods=48)
    assert result.shape == (48, 2)


def test_encode_codes():
    from healthgpt.preprocessing import encode_clinical_codes
    vocab = {"E11": 1, "I10": 2, "J18": 3}
    codes = ["E11", "I10", "UNKNOWN"]
    encoded = encode_clinical_codes(codes, vocab, unknown_id=0)
    assert encoded == [1, 2, 0]


def test_build_patient_sequence():
    from healthgpt.preprocessing import build_patient_sequence
    result = build_patient_sequence(
        code_ids=[1, 2, 3],
        lab_array=np.zeros((48, 10)),
        note_embedding=np.zeros(768),
        imaging_embedding=np.zeros(512),
        demographics=np.zeros(8),
    )
    assert "code_ids" in result
    assert result["code_ids"].shape == (1, 3)
    assert result["lab_seq"].shape == (1, 48, 10)
